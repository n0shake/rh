#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double LocksmithVersionNumber;
FOUNDATION_EXPORT const unsigned char LocksmithVersionString[];